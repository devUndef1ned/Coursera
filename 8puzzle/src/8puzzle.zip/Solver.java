import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Stack;


public class Solver {

    private SearchNode solutionNode;
    private boolean isSolvable = false;
    private final SearchNode initialNode;
    private final SearchNode initialTwinedNode;
    private Stack<Board> solution = new Stack<Board>();

    // find a solution to the initial board (using the A* algorithm)
    public Solver(Board initial) {
        if (initial == null)
            throw new NullPointerException();

        final Board initialBoard = initial;

        final MinPQ<SearchNode> mQueue = new MinPQ<SearchNode>();
        //final MinPQ<SearchNode> mTwinedQueue = new MinPQ<SearchNode>();

        initialNode = new SearchNode(initialBoard, null);
        initialTwinedNode = new SearchNode(initialBoard.twin(), null);

        mQueue.insert(initialNode);
        //mTwinedQueue.insert(new SearchNode(initialBoard.twin(), null));

        while (true) {
            SearchNode min = insertNeighborsToQueueAndGetMin(mQueue);
            //SearchNode twinedMin = insertNeighborsToQueueAndGetMin(mTwinedQueue);

            if (min != null && min.getBoard().isGoal()) {
                solutionNode = min;
                break;
            }

            //if (twinedMin != null && twinedMin.getBoard().isGoal())
             //   break;
        }


        SearchNode cur = solutionNode;

        do {
            solution.push(cur.getBoard());
            cur = cur.getPreviousNode();
        } while(cur.getPreviousNode() != null);

        if (cur.getBoard().equals(initialTwinedNode.getBoard()))
            isSolvable = false;
        else
            isSolvable = true;

    }
    private SearchNode insertNeighborsToQueueAndGetMin(MinPQ<SearchNode> queue) {
        if (queue == null || queue.isEmpty())
            return null;

        SearchNode min = queue.delMin();

        if (min.getBoard().isGoal())
            return min;

        Iterable<Board> iterable = min.getBoard().neighbors();
        for (Board board: iterable) {
            if ((min.getPreviousNode() == null) || !(board.equals(min.getBoard())))
                queue.insert(new SearchNode(board, min));
        }

        return min;
    }
    // is the initial board solvable?
    public boolean isSolvable() {
        return isSolvable;
    }
    // min number of moves to solve initial board; -1 if unsolvable
    public int moves() {
        if (isSolvable())
            return solutionNode.moves;
        else
            return -1;
    }
    // sequence of boards in a shortest solution; null if unsolvable
    public Iterable<Board> solution() {
        if (!isSolvable())
            return null;

        ArrayList<Board> revertedSolution = new ArrayList<Board>();
        while (true) {
            if (solution.isEmpty())
                break;
            else
                revertedSolution.add(solution.pop());
        }

        return revertedSolution;
    }

    private class SearchNode implements Comparable<SearchNode> {
        private Board mBoard;
        private SearchNode mPreviousNode;
        private int moves;
        private int priority;

        public SearchNode(Board thisBoard, SearchNode previousNode) {
            mBoard = thisBoard;
            mPreviousNode = previousNode;
            if (previousNode == null)
                moves = 0;
            else
                moves = previousNode.moves + 1;
            priority = moves + mBoard.manhattan();
        }

        public int priority() {
            return priority;
        }

        public Board getBoard() {
            return mBoard;
        }

        public SearchNode getPreviousNode() {
            return mPreviousNode;
        }

        @Override
        public int compareTo(SearchNode o) {
            int diff = priority - o.priority;

            if (diff == 0)
                diff = getBoard().hamming() - o.getBoard().hamming();

           return diff;
        }
    }

    // solve a slider puzzle (given below)
    public static void main(String[] args) {
        // create initial board from file
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] blocks = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                blocks[i][j] = in.readInt();
        Board initial = new Board(blocks);

        // long timeBefore = new Date().getTime();
        // solve the puzzle
        Solver solver = new Solver(initial);

        // long timeAfter = new Date().getTime();

        // System.out.println("Spent time to solve puzzle is " + (timeAfter - timeBefore)/1000 + "."
        // + (timeAfter - timeBefore)%1000 + " s");

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }
}
