import edu.princeton.cs.algs4.StdRandom;

import java.util.ArrayList;
import java.util.List;

public class Board {

    private static final int BLANK = 0;
    private static final int NOT_INITIALIZED_PRIORITY = -10;

    private final int[] mBlocks;
    private final int blocksSize;

    private int manhattan = NOT_INITIALIZED_PRIORITY;
    private int hamming = NOT_INITIALIZED_PRIORITY;

    // construct a board from an n-by-n array of blocks
    // (where blocks[i][j] = block in row i, column j)
    public Board(int[][] blocks) {
        if (blocks == null)
            throw new NullPointerException();

        blocksSize = blocks[0].length;
        mBlocks = new int[blocksSize * blocksSize];

        for (int i = 0; i < blocksSize; i++) {
            for (int j = 0; j < blocksSize; j++) {
                mBlocks[i * dimension() + j] = blocks[i][j];
            }
        }
    }
    // board dimension n
    public int dimension() {
        return blocksSize;
    }
    // number of blocks out of place
    public int hamming() {
        if (hamming == NOT_INITIALIZED_PRIORITY) {
            hamming = 0;
            for (int i = 0; i < dimension(); i++) {
                for (int j = 0; j < dimension(); j++) {
                    if (mBlocks[i * dimension() + j] == BLANK)
                        continue;
                    if (i != getExpectedRowIndex(mBlocks[i * dimension() + j]) ||
                            j != getExpectedColumnIndex(mBlocks[i * dimension() + j]))
                        hamming++;
                }
            }
        }
        return hamming;
    }
    // sum of Manhattan distances between blocks and goal
    public int manhattan() {
        if (manhattan == NOT_INITIALIZED_PRIORITY) {
            manhattan = 0;
            for (int i = 0; i < dimension(); i++) {
                for (int j = 0; j < dimension(); j++) {
                    if (mBlocks[i * dimension() + j] == BLANK)
                        continue;
                    manhattan += Math.abs(i - getExpectedRowIndex(mBlocks[i * dimension() + j]));
                    manhattan += Math.abs(j - getExpectedColumnIndex(mBlocks[i * dimension() + j]));
                }
            }
        }
        return manhattan;
    }
    // is this board the goal board?
    public boolean isGoal() {
        return manhattan() == 0;
    }
    // a board that is obtained by exchanging any pair of blocks
    public Board twin() {
        int i1 = StdRandom.uniform(dimension());
        int i2 = StdRandom.uniform(dimension());
        int j1 = StdRandom.uniform(dimension());
        int j2 = StdRandom.uniform(dimension());

        while (true) {
            if (mBlocks[i1 * dimension() + j1] == BLANK ||
                    mBlocks[i2 * dimension() + j2] == BLANK ||
                    ((i1 == i2) && (j1 == j2))) {
                i1 = StdRandom.uniform(dimension());
                i2 = StdRandom.uniform(dimension());
                j1 = StdRandom.uniform(dimension());
                j2 = StdRandom.uniform(dimension());
            } else {
                break;
            }
        }

        return exchangedBoard(i1, j1, i2, j2);
    }
    // does this board equal y?
    public boolean equals(Object y) {
        if (y == null)
            return false;

        if (y == this)
            return true;

        if (y.getClass() != this.getClass())
            return false;

        Board that = (Board) y;

        if (this.dimension() != that.dimension())
            return false;

        int[] thatBlocks = that.mBlocks;

        for (int i = 0; i < dimension() * dimension(); i++) {
                if (mBlocks[i] != thatBlocks[i])
                    return false;
        }
        return true;
    }
    // all neighboring boards
    public Iterable<Board> neighbors() {
        List<Board> mNeighbors = new ArrayList<Board>();
            int blankRow = getRowIndexOfBlank();
            int blankColumn = getColumnIndexOfBlank();
            // exchange blank with top
            if (blankRow > 0)
                mNeighbors.add(exchangedBoard(blankRow, blankColumn, blankRow - 1, blankColumn));
            // exchange blank with bottom
            if (blankRow < maxIndex())
                mNeighbors.add(exchangedBoard(blankRow, blankColumn, blankRow + 1, blankColumn));
            // exchange blank with left
            if (blankColumn > 0)
                mNeighbors.add(exchangedBoard(blankRow, blankColumn, blankRow, blankColumn - 1));
            // exchange blank with right
            if (blankColumn < maxIndex())
                mNeighbors.add(exchangedBoard(blankRow, blankColumn, blankRow, blankColumn + 1));

        return mNeighbors;
    }
    // string representation of this board (in the output format specified below)
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(dimension()).append('\n');
        for (int i = 0; i < dimension(); i++) {
            for (int j = 0; j < dimension(); j++) {
                builder.append(String.format("%2d ", mBlocks[i * dimension() + j]));
            }
            builder.append('\n');
        }
        return builder.toString();
    }
    private int getExpectedRowIndex(int a) {
        if (a == 0)
            return dimension() - 1;

        return (a - 1)/dimension();
    }
    private int getExpectedColumnIndex(int a) {
        if (a == 0)
            return dimension() - 1;

        return a - dimension()*getExpectedRowIndex(a) - 1;
    }
    private int maxIndex() {
        return dimension() - 1;
    }
    private int getRowIndexOfBlank() {
        int row = 0;
        for (int i = 0; i < dimension(); i++) {
            for (int j = 0; j < dimension(); j++) {
                if (mBlocks[i * dimension() + j] == BLANK)
                    row = i;
            }
        }
        return row;
    }
    private int getColumnIndexOfBlank() {
        int column = 0;
        for (int i = 0; i < dimension(); i++) {
            for (int j = 0; j < dimension(); j++) {
                if (mBlocks[i * dimension() + j] == BLANK)
                    column = j;
            }
        }
        return column;
    }
    private Board exchangedBoard(int i1, int j1, int i2, int j2) {
        Board exchangedBoard;
        int[][] exchangedBlocks = new int[dimension()][dimension()];
        for (int i = 0; i < dimension(); i++) {
            for (int j = 0; j < dimension(); j++) {
                exchangedBlocks[i][j] = mBlocks[i * dimension() + j];
            }
        }
        exchangedBoard = new Board(exchangedBlocks);
        int tmp = mBlocks[i1 * dimension() + j1];
        exchangedBoard.mBlocks[i1 * dimension() + j1] = mBlocks[i2 * dimension() + j2];
        exchangedBoard.mBlocks[i2 * dimension() + j2] = tmp;

        return exchangedBoard;

    }
}
